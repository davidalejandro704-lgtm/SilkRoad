package shapes;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.*;

public class Canvas {
    private static Canvas canvasSingleton;
    private List<int[]> coordinatesMap; // Mapa de posiciones a coordenadas

    public static Canvas getCanvas() {
        if (canvasSingleton == null) {
            canvasSingleton = new Canvas("BlueJ Shapes Demo", 1000, 800, Color.white);
        }
        canvasSingleton.setVisible(true);
        return canvasSingleton;
    }

    private JFrame frame;
    private CanvasPane canvas;
    private Graphics2D graphic;
    private Color backgroundColour;
    private Image canvasImage;
    private List<Object> objects;
    private HashMap<Object, ShapeDescription> shapes;

    private Canvas(String title, int width, int height, Color bgColour) {
        frame = new JFrame();
        canvas = new CanvasPane();
        frame.setContentPane(canvas);
        frame.setTitle(title);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        canvas.setPreferredSize(new Dimension(width, height));
        backgroundColour = bgColour;
        frame.pack();
        objects = new ArrayList<Object>();
        shapes = new HashMap<Object, ShapeDescription>();
        coordinatesMap = new ArrayList<>();
    }

    /**
     * Crea un tablero espiral y guarda el mapa de coordenadas
     */
    public void length(int totalCells) {
        if (totalCells <= 0) return;
        
        clearBoard();
        coordinatesMap.clear();
        
        int cellSize = 30;
        int x = 400;  // Centro del canvas más grande
        int y = 300;  // Centro del canvas más grande
        
        // Agregar posición 1 (centro)
        coordinatesMap.add(new int[]{x, y});
        drawBoardCell(x, y, cellSize, "lightGray", 0);
        drawNumber(x, y, cellSize, 1);
        
        if (totalCells == 1) {
            redraw();
            return;
        }
        
        int currentNumber = 2;
        int[] segmentLengths = {1, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        int direction = 0; // 0=derecha, 1=abajo, 2=izquierda, 3=arriba
        
        for (int segmentLength : segmentLengths) {
            if (currentNumber > totalCells) break;
            
            for (int i = 0; i < segmentLength && currentNumber <= totalCells; i++) {
                // Mover en la dirección actual
                switch (direction) {
                    case 0: x += cellSize; break;
                    case 1: y += cellSize; break;
                    case 2: x -= cellSize; break;
                    case 3: y -= cellSize; break;
                }
                
                coordinatesMap.add(new int[]{x, y});
                drawBoardCell(x, y, cellSize, "lightGray", currentNumber - 1);
                drawNumber(x, y, cellSize, currentNumber);
                currentNumber++;
            }
            
            direction = (direction + 1) % 4;
        }
        
        redraw();
    }

    /**
     * Obtiene coordenadas para una posición del tablero
     */
    public int[] getCoordinatesForPosition(int position) {
        if (position < 1 || position > coordinatesMap.size()) {
            return new int[]{400, 300}; // Centro por defecto
        }
        return coordinatesMap.get(position - 1);
    }

    /**
     * Obtiene el número total de casillas creadas
     */
    public int getBoardSize() {
        return coordinatesMap.size();
    }

    private void drawBoardCell(int x, int y, int size, String color, int id) {
        java.awt.Rectangle rect = new java.awt.Rectangle(x, y, size, size);
        Object cellKey = "cell_" + id;
        draw(cellKey, color, rect);
        
        Object borderKey = "border_" + id;
        drawBorder(borderKey, "black", new java.awt.Rectangle(x, y, size, size));
    }

    private void drawNumber(int x, int y, int cellSize, int number) {
        if (graphic == null) return;
        
        Color originalColor = graphic.getColor();
        graphic.setColor(Color.black);
        graphic.setFont(new Font("Arial", Font.BOLD, 10));
        
        String numberText = String.valueOf(number);
        FontMetrics fm = graphic.getFontMetrics();
        int textWidth = fm.stringWidth(numberText);
        
        int centerX = x + (cellSize - textWidth) / 2;
        int centerY = y + (cellSize / 2) + 3;
        
        graphic.drawString(numberText, centerX, centerY);
        graphic.setColor(originalColor);
    }

    // ... (el resto de los métodos se mantienen igual)
    private void drawBorder(Object referenceObject, String color, Shape shape) {
        objects.remove(referenceObject);
        objects.add(referenceObject);
        shapes.put(referenceObject, new BorderShapeDescription(shape, color));
    }

    private void clearBoard() {
        List<Object> toRemove = new ArrayList<>();
        for (Object obj : objects) {
            if (obj instanceof String) {
                String strObj = (String) obj;
                if (strObj.startsWith("cell_") || strObj.startsWith("border_")) {
                    toRemove.add(obj);
                }
            }
        }
        
        for (Object obj : toRemove) {
            objects.remove(obj);
            shapes.remove(obj);
        }
    }

    public void setVisible(boolean visible) {
        if (graphic == null) {
            Dimension size = canvas.getSize();
            canvasImage = canvas.createImage(size.width, size.height);
            graphic = (Graphics2D) canvasImage.getGraphics();
            graphic.setColor(backgroundColour);
            graphic.fillRect(0, 0, size.width, size.height);
            graphic.setColor(Color.black);
        }
        frame.setVisible(visible);
    }

    public void draw(Object referenceObject, String color, Shape shape) {
        objects.remove(referenceObject);
        objects.add(referenceObject);
        shapes.put(referenceObject, new ShapeDescription(shape, color));
        redraw();
    }

    public void erase(Object referenceObject) {
        objects.remove(referenceObject);
        shapes.remove(referenceObject);
        redraw();
    }

    public void setForegroundColor(String colorString) {
        if (colorString.equals("red")) graphic.setColor(Color.red);
        else if (colorString.equals("black")) graphic.setColor(Color.black);
        else if (colorString.equals("blue")) graphic.setColor(Color.blue);
        else if (colorString.equals("yellow")) graphic.setColor(Color.yellow);
        else if (colorString.equals("green")) graphic.setColor(Color.green);
        else if (colorString.equals("magenta")) graphic.setColor(Color.magenta);
        else if (colorString.equals("white")) graphic.setColor(Color.white);
        else if (colorString.equals("lightGray")) graphic.setColor(Color.lightGray);
        else if (colorString.equals("gray")) graphic.setColor(Color.gray);
        else graphic.setColor(Color.black);
    }

    public void wait(int milliseconds) {
        try { Thread.sleep(milliseconds); } catch (Exception e) {}
    }

    private void redraw() {
        eraseBackground();
        for (Object obj : objects) {
            ShapeDescription desc = shapes.get(obj);
            if (desc != null) desc.draw(graphic);
        }
        canvas.repaint();
    }

    private void eraseBackground() {
        Color original = graphic.getColor();
        graphic.setColor(backgroundColour);
        Dimension size = canvas.getSize();
        graphic.fillRect(0, 0, size.width, size.height);
        graphic.setColor(original);
    }

    private class CanvasPane extends JPanel {
        public void paint(Graphics g) {
            g.drawImage(canvasImage, 0, 0, null);
        }
    }

    private class ShapeDescription {
        protected Shape shape;
        protected String colorString;

        public ShapeDescription(Shape shape, String color) {
            this.shape = shape;
            colorString = color;
        }

        public void draw(Graphics2D graphic) {
            setForegroundColor(colorString);
            graphic.fill(shape);
        }
    }

    private class BorderShapeDescription extends ShapeDescription {
        public BorderShapeDescription(Shape shape, String color) {
            super(shape, color);
        }

        @Override
        public void draw(Graphics2D graphic) {
            setForegroundColor(colorString);
            graphic.draw(shape);
        }
    }
}