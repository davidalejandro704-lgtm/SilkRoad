package SilkRoad;

import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Arrays;
import java.util.*;

public class SilkRoadContestTest {
    
    @Test
    public void testSolveAlgorithmEfficiency() {
        System.out.println("=== PRUEBA ALGORITMO EFICIENTE ===");
        
        int[][] days = {
            {1, 20},
            {2, 15, 15},
            {2, 40, 50},
            {1, 50},
            {2, 80, 20},
            {2, 70, 30}
        };
        
        int[] expected = {0, 10, 35, 50, 50, 60};
        int[] result = SilkRoadContest.solve(days);
        
        System.out.println("Resultado algoritmo: " + Arrays.toString(result));
        assertArrayEquals("El algoritmo debe resolver correctamente", expected, result);
    }
    
    @Test
    public void testSolveNoGraphicalDependency() {
        System.out.println("=== PRUEBA SIN DEPENDENCIA GRÁFICA ===");
        
        // Esta prueba verifica que solve() funciona sin instanciar SilkRoad
        int[][] days = {
            {1, 10},
            {2, 5, 20},
            {1, 15},
            {2, 20, 30}
        };
        
        // No debería haber errores de Canvas o shapes
        try {
            int[] result = SilkRoadContest.solve(days);
            assertTrue("Debe calcular profits sin errores", result.length == 4);
            System.out.println("✓ Algoritmo funciona sin dependencias gráficas");
        } catch (Exception e) {
            fail("El algoritmo no debe depender de componentes gráficos: " + e.getMessage());
        }
    }
    
    @Test
    public void testSolveLargeInput() {
        System.out.println("=== PRUEBA ENTRADA GRANDE ===");
        
        // Probar con máximo tamaño permitido (n = 20000)
        int n = 100; // Usar 100 para prueba rápida
        int[][] days = new int[n][];
        
        for (int i = 0; i < n; i++) {
            if (i % 2 == 0) {
                days[i] = new int[]{1, i * 10}; // Robots en posiciones pares
            } else {
                days[i] = new int[]{2, i * 10 + 5, (i + 1) * 10}; // Tiendas en impares
            }
        }
        
        long startTime = System.currentTimeMillis();
        int[] result = SilkRoadContest.solve(days);
        long endTime = System.currentTimeMillis();
        
        System.out.println("Tiempo ejecución: " + (endTime - startTime) + "ms");
        assertTrue("Debe completar en tiempo razonable", (endTime - startTime) < 5000);
    }
    
    @Test
    public void testSolveEdgeCases() {
        System.out.println("=== PRUEBAS CASOS BORDE ===");
        
        // Caso 1: Distancias grandes pero profit positivo
        int[][] days1 = {
            {1, 0},
            {2, 1000, 2000} // Profit: 2000 - 1000 = 1000
        };
        int[] result1 = SilkRoadContest.solve(days1);
        assertEquals("Debe aceptar profits positivos con distancias grandes", 1000, result1[1]);
        
        // Caso 2: Múltiples opciones, elegir la mejor
        int[][] days2 = {
            {1, 10},
            {2, 5, 20},   // Profit: 20 - 5 = 15
            {2, 15, 25}   // Profit: 25 - 5 = 20 (mejor)
        };
        int[] result2 = SilkRoadContest.solve(days2);
        assertTrue("Debe elegir la asignación con mayor profit", result2[2] >= 20);
        
        System.out.println(" Todos los casos borde funcionan correctamente");
    }
    
    @Test
    public void testSeparationOfConcerns() {
        System.out.println("=== PRUEBA SEPARACIÓN DE RESPONSABILIDADES ===");
        
        // Verificar que SilkRoadContest.solve() no usa SilkRoad internamente
        int[][] simpleDays = {{1, 10}, {2, 20, 30}};
        
        // Esta ejecución no debe crear objetos Canvas ni shapes
        try {
            int[] result = SilkRoadContest.solve(simpleDays);
            
            // Verificar que son valores razonables
            assertTrue("Profit debe ser calculado", result[0] == 0);
            assertTrue("Profit día 2 debe ser >= 0", result[1] >= 0);
            
            System.out.println(" Separación de responsabilidades correcta");
            System.out.println("  - solve() = Lógica de negocio pura");
            System.out.println("  - simulate() = Simulación visual con SilkRoad");
            
        } catch (Exception e) {
            fail("solve() no debe depender de componentes gráficos: " + e.getMessage());
        }
    }
}