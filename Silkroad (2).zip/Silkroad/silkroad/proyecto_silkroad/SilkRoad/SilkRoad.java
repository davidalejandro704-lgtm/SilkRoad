package SilkRoad;
import shapes.*;
import java.util.*;

public class SilkRoad {
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    private int profit;
    private Rectangle profitBar;
    private boolean isVisible;
    private ArrayList<int[]> profitHistory;
    private Canvas canvas;

    // CONSTRUCTOR NORMAL
    public SilkRoad() {
        stores = new ArrayList<>();
        robots = new ArrayList<>();
        profit = 0;
        profitBar = null;
        isVisible = false;
        profitHistory = new ArrayList<>();
        canvas = Canvas.getCanvas();
    }

    // MÉTODO length - según el PDF: + (length : int) : SilkRoad
    public SilkRoad length(int length) {
        System.out.println("Configurando longitud del tablero: " + length);
        canvas.length(length);
        return this; // Retorna this para encadenamiento
    }

    // MÉTODO days - según el PDF: + _(days : int[][]) : SilkRoad  
    public SilkRoad days(int[][] days) {
        System.out.println(" Configurando días automáticamente");
        // Limpiar cualquier configuración previa
        stores.clear();
        robots.clear();
        profit = 0;
        
        // Procesar los días
        for (int i = 0; i < days.length; i++) {
            if (days[i][0] == 1) {
                // Es un robot
                placeRobot(days[i][1]);
            } else if (days[i][0] == 2) {
                // Es una tienda
                placeStore(days[i][1], days[i][2]);
            }
        }
        return this; // Retorna this para encadenamiento
    }

    // MÉTODOS PARA CONFIGURACIÓN MANUAL
    public void placeStore(int location, int tenges) {
        Store newStore = new Store(location, tenges);
        stores.add(newStore);
        if (isVisible) {
            newStore.getRect().makeVisible();
        }
        System.out.println(" Tienda colocada en: " + location + " con " + tenges + " tenges");
    }

    public void placeRobot(int location) {
        String color = getNextRobotColor();
        Robot newRobot = new Robot(location, color);
        robots.add(newRobot);
        if (isVisible) {
            newRobot.getCircle().makeVisible();
        }
        System.out.println(" Robot colocado en: " + location + " (color: " + color + ")");
    }

    // MÉTODO PARA MOVER ROBOTS
    public void moveRobots() {
        System.out.println(" Moviendo robots para maximizar profit...");
        int dailyProfit = 0;
        
        // Reiniciar historial
        profitHistory.clear();
        
        // Para cada robot, encontrar la mejor tienda disponible
        for (Robot robot : robots) {
            Store bestStore = null;
            int bestProfit = 0;
            
            // Buscar la mejor tienda para este robot
            for (Store store : stores) {
                if (store.getMoney() > 0) { // Solo tiendas con dinero
                    int distance = Math.abs(store.getPosition() - robot.getPosition());
                    int storeProfit = store.getMoney() - distance;
                    
                    if (storeProfit > bestProfit) {
                        bestProfit = storeProfit;
                        bestStore = store;
                    }
                }
            }
            
            // Si encontramos una tienda buena, mover el robot
            if (bestStore != null && bestProfit > 0) {
                // Mover visualmente
                robot.moveTo(bestStore.getPosition());
                
                // Colectar dinero
                int collected = bestStore.collectMoney();
                robot.addProfit(collected);
                dailyProfit += collected;
                
                // Registrar en historial
                profitHistory.add(new int[]{
                    robot.getPosition(), 
                    bestProfit,
                    bestStore.getPosition()
                });
                
                System.out.println("  Robot " + robot.getPosition() + " → Tienda " + 
                                 bestStore.getPosition() + " = " + bestProfit + " profit");
            }
        }
        
        profit += dailyProfit;
        updateProfitBar();
        System.out.println(" Profit del movimiento: " + dailyProfit);
    }

    public int profit() {
        return profit;
    }

    public void makeVisible() {
        isVisible = true;
        // Hacer visibles todos los elementos
        for (Store store : stores) {
            store.getRect().makeVisible();
        }
        for (Robot robot : robots) {
            robot.getCircle().makeVisible();
        }
        if (profitBar != null) {
            profitBar.makeVisible();
        }
        System.out.println("  Simulación visible");
    }

    public void makeInvisible() {
        isVisible = false;
        // Ocultar todos los elementos
        for (Store store : stores) {
            store.getRect().makeInvisible();
        }
        for (Robot robot : robots) {
            robot.getCircle().makeInvisible();
        }
        if (profitBar != null) {
            profitBar.makeInvisible();
        }
        System.out.println(" Simulación oculta");
    }

    public void reboot() {
        System.out.println(" Reiniciando sistema...");
        // Reabastecer tiendas
        for (Store store : stores) {
            store.resupply();
        }
        // Devolver robots a sus posiciones originales
        for (Robot robot : robots) {
            robot.returnToStart();
        }
        profit = 0;
        profitHistory.clear();
        updateProfitBar();
        System.out.println(" Sistema reiniciado");
    }

    // MÉTODOS DE CONSULTA
    public String stores() {
        if (stores.isEmpty()) return "No hay tiendas";
        
        StringBuilder sb = new StringBuilder(" Tiendas:\n");
        for (Store store : stores) {
            sb.append("  Posición ").append(store.getPosition())
              .append(": ").append(store.getMoney()).append(" tenges\n");
        }
        return sb.toString();
    }

    public String robots() {
        if (robots.isEmpty()) return "No hay robots";
        
        StringBuilder sb = new StringBuilder(" Robots:\n");
        for (Robot robot : robots) {
            sb.append("  Posición ").append(robot.getPosition())
              .append(": ").append(robot.getProfit()).append(" profit\n");
        }
        return sb.toString();
    }

    public void printStatus() {
        System.out.println("=== ESTADO SILKROAD ===");
        System.out.println(stores());
        System.out.println(robots());
        System.out.println("Profit total: " + profit);
        System.out.println("========================");
    }

    // MÉTODOS AUXILIARES PRIVADOS
    private String getNextRobotColor() {
        String[] colors = {"red", "green", "blue", "yellow", "magenta"};
        return colors[robots.size() % colors.length];
    }

    private void updateProfitBar() {
        if (profitBar == null) {
            profitBar = new Rectangle();
            profitBar.changeColor("yellow");
            profitBar.changeSize(10, 20);
            profitBar.moveHorizontal(50);
            profitBar.moveVertical(550);
            if (isVisible) {
                profitBar.makeVisible();
            }
        }
        // Actualizar tamaño según profit
        int width = Math.min(profit + 10, 300);
        profitBar.changeSize(width, 20);
    }

    // LOS DEMÁS MÉTODOS REQUERIDOS (removeStore, removeRobot, etc.)
    public void removeStore(int location) {
        stores.removeIf(store -> store.getPosition() == location);
        System.out.println(" Tienda removida de posición: " + location);
    }

    public void removeRobot(int location) {
        robots.removeIf(robot -> robot.getPosition() == location);
        System.out.println(" Robot removido de posición: " + location);
    }

    public void finish() {
        System.out.println(" Simulación finalizada");
        System.out.println("Profit total final: " + profit);
    }

    public boolean ok() {
        return !stores.isEmpty() || !robots.isEmpty();
    }
}