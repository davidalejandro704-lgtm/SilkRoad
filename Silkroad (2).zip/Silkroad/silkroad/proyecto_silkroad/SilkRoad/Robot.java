package SilkRoad;
import shapes.*;
import java.util.*;

public class Robot {
    private Circle circle;
    private int position;
    private int originalPosition; // Guardar posición original
    private String color;
    private int profit;

    public Robot(int pos, String color) {
        this.position = pos;
        this.originalPosition = pos; // Guardar posición original
        this.color = color;
        this.profit = 0;

        int[] coords = Canvas.getCanvas().getCoordinatesForPosition(pos);
        
        circle = new Circle();
        circle.changeColor(color);
        circle.changeSize(18);
        circle.moveHorizontal(coords[0] + 6);
        circle.moveVertical(coords[1] + 6);
        circle.makeVisible();
    }

    public void moveTo(int targetPosition) {
        int[] currentCoords = Canvas.getCanvas().getCoordinatesForPosition(position);
        int[] targetCoords = Canvas.getCanvas().getCoordinatesForPosition(targetPosition);
        
        circle.moveHorizontal(targetCoords[0] - currentCoords[0]);
        circle.moveVertical(targetCoords[1] - currentCoords[1]);
        position = targetPosition;
    }
    
    public void returnToStart() {
        int[] currentCoords = Canvas.getCanvas().getCoordinatesForPosition(position);
        int[] startCoords = Canvas.getCanvas().getCoordinatesForPosition(originalPosition);
        
        circle.moveHorizontal(startCoords[0] - currentCoords[0]);
        circle.moveVertical(startCoords[1] - currentCoords[1]);
        position = originalPosition;
        profit = 0; // Resetear profit
    }

    public int getPosition() { return position; }
    public String getColor() { return color; }
    public int getProfit() { return profit; }
    public void addProfit(int value) { profit += value; }
    public void resetProfit() { profit = 0; }
    
    // Métodos para acceso desde SilkRoad
    public Circle getCircle() { return circle; }
    public int getOriginalPosition() { return originalPosition; }
    
    public void blink() {
        for (int i = 0; i < 5; i++) {
            circle.makeInvisible();
            try { Thread.sleep(300); } catch (InterruptedException e) {}
            circle.makeVisible();
            try { Thread.sleep(300); } catch (InterruptedException e) {}
        }
    }
}