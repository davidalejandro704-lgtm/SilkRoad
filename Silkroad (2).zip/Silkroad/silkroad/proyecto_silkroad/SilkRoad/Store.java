package SilkRoad;
import shapes.*;
import java.util.*;

public class Store {
    private int pos;
    private int money;
    private int originalMoney; // Guardar el dinero original
    private int emptyCount;
    private Rectangle rect;

    public Store(int pos, int money) {
        this.pos = pos;
        this.money = money;
        this.originalMoney = money; // Guardar el original
        this.emptyCount = 0;

        int[] coords = Canvas.getCanvas().getCoordinatesForPosition(pos);
        
        rect = new Rectangle();
        rect.changeColor("blue");
        rect.changeSize(20, 20);
        rect.moveHorizontal(coords[0] + 5);
        rect.moveVertical(coords[1] + 5);
        rect.makeVisible();
    }

    public int getPosition() { return pos; }
    public int getMoney() { return money; }
    
    public int collectMoney() {
        int collected = money;
        money = 0;
        emptyCount++;
        rect.changeColor("gray");
        return collected;
    }
    
    public void resupply() {
        money = originalMoney; // Restaurar el dinero original
        rect.changeColor("blue");
    }
    
    public int getEmptyCount() { return emptyCount; }
    
    // Métodos para acceso desde SilkRoad
    public Rectangle getRect() { return rect; }
    public void setMoney(int money) { this.money = money; }
}