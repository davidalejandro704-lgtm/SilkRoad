package SilkRoad;

public class SilkRoadContest {
    
    public static int[] solve(int[][] days) {
        System.out.println(" INICIANDO SOLVE...");
        int n = days.length;
        int[] result = new int[n];
        
        // Usar arrays normales en lugar de TreeSet/TreeMap
        java.util.ArrayList<Integer> robots = new java.util.ArrayList<>();
        java.util.ArrayList<int[]> stores = new java.util.ArrayList<>(); // [location, tenges]
        
        for (int i = 0; i < n; i++) {
            System.out.println(" Procesando día " + (i+1) + ": " + java.util.Arrays.toString(days[i]));
            
            if (days[i][0] == 1) {
                // Nuevo robot
                robots.add(days[i][1]);
                System.out.println(" Robot añadido en: " + days[i][1]);
            } else {
                // Nueva tienda
                int[] store = {days[i][1], days[i][2]};
                stores.add(store);
                System.out.println(" Tienda añadida en: " + days[i][1] + " con " + days[i][2] + " tenges");
            }
            
            result[i] = calculateMaxProfit(robots, stores);
            System.out.println(" Profit día " + (i+1) + ": " + result[i]);
        }
        
        System.out.println(" RESULTADO FINAL: " + java.util.Arrays.toString(result));
        return result;
    }
    
    private static int calculateMaxProfit(java.util.ArrayList<Integer> robots, java.util.ArrayList<int[]> stores) {
        if (robots.isEmpty() || stores.isEmpty()) {
            return 0;
        }
        
        int totalProfit = 0;
        
        // Crear copias para no modificar los originales
        java.util.ArrayList<Integer> availableRobots = new java.util.ArrayList<>(robots);
        java.util.ArrayList<int[]> availableStores = new java.util.ArrayList<>(stores);
        
        while (!availableRobots.isEmpty() && !availableStores.isEmpty()) {
            int bestProfit = -1;
            Integer bestRobot = null;
            int[] bestStore = null;
            int bestStoreIndex = -1;
            
            // Buscar la mejor combinación
            for (int i = 0; i < availableRobots.size(); i++) {
                Integer robot = availableRobots.get(i);
                
                for (int j = 0; j < availableStores.size(); j++) {
                    int[] store = availableStores.get(j);
                    int storeLoc = store[0];
                    int storeTenges = store[1];
                    
                    int distance = Math.abs(storeLoc - robot);
                    int profit = storeTenges - distance;
                    
                    if (profit > bestProfit && profit > 0) {
                        bestProfit = profit;
                        bestRobot = robot;
                        bestStore = store;
                        bestStoreIndex = j;
                    }
                }
            }
            
            if (bestProfit > 0) {
                totalProfit += bestProfit;
                availableRobots.remove(bestRobot);
                availableStores.remove(bestStoreIndex);
                System.out.println(" Asignación: Robot " + bestRobot + " → Tienda " + bestStore[0] + " = " + bestProfit + " profit");
            } else {
                break;
            }
        }
        
        return totalProfit;
    }
    
    // MÉTODO DE PRUEBA SIMPLE - SIN PARÁMETROS
    public static void testarSolucion() {
        System.out.println(" INICIANDO PRUEBA AUTOMÁTICA");
        
        // Caso de prueba simple
        int[][] diasPrueba = {
            {1, 20},
            {2, 15, 15},
            {2, 40, 50}
        };
        
        System.out.println(" Datos de prueba:");
        for (int i = 0; i < diasPrueba.length; i++) {
            if (diasPrueba[i][0] == 1) {
                System.out.println("  Día " + (i+1) + ": Robot en " + diasPrueba[i][1]);
            } else {
                System.out.println("  Día " + (i+1) + ": Tienda en " + diasPrueba[i][1] + " con " + diasPrueba[i][2] + " tenges");
            }
        }
        
        int[] resultados = solve(diasPrueba);
        
        System.out.println(" Resultados obtenidos:");
        for (int i = 0; i < resultados.length; i++) {
            System.out.println("  Día " + (i+1) + ": " + resultados[i] + " tenges");
        }
        
        // Verificación básica
        if (resultados[0] == 0 && resultados[1] > 0 && resultados[2] > resultados[1]) {
            System.out.println(" ¡PRUEBA EXITOSA! El algoritmo funciona correctamente");
        } else {
            System.out.println(" Prueba completada, verificar resultados manualmente");
        }
    }
    
    // MÉTODO DE PRUEBA CON EL CASO OFICIAL
    public static void pruebaCasoOficial() {
        System.out.println(" PRUEBA CASO OFICIAL DEL PROBLEMA");
        
        int[][] diasOficial = {
            {1, 20},
            {2, 15, 15},
            {2, 40, 50},
            {1, 50},
            {2, 80, 20},
            {2, 70, 30}
        };
        
        int[] resultados = solve(diasOficial);
        int[] esperados = {0, 10, 35, 50, 50, 60};
        
        System.out.println(" Comparando resultados:");
        boolean correcto = true;
        for (int i = 0; i < resultados.length; i++) {
            String estado = (resultados[i] == esperados[i]) ? "✓" : "✗";
            if (resultados[i] != esperados[i]) correcto = false;
            System.out.println("  Día " + (i+1) + ": " + resultados[i] + " " + estado + " (esperado: " + esperados[i] + ")");
        }
        
        if (correcto) {
            System.out.println("¡FELICIDADES! Caso oficial resuelto correctamente");
        } else {
            System.out.println(" El algoritmo necesita ajustes");
        }
    }
    
    public static void simulate(int[][] days, boolean slow) {
        System.out.println(" Iniciando simulación visual...");
        // Tu código de simulación existente
    }
}